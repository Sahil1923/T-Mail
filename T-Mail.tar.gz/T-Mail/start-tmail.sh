clear
cd files
python3 Tmail.py
cd -
clear
