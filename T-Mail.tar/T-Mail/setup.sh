apt install python -y
apt install python2 -y
apt install python3 -y
pip install --upgrade pip
pip install pyfiglet
clear
echo "[Setup] Installation Finished! To run type './start-tmail.sh'..."
chmod +x *
